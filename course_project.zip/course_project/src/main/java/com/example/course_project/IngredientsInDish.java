package com.example.course_project;

public class IngredientsInDish {
}
